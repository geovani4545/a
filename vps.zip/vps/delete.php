
<!DOCTYPE html>
<html>
<head>
  <title>form</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>
<body>
  <div class="container">
    <h2 style="text-align: center;">Isi semua kolom</h2>
    <form action="" method="post" enctype="multipart/form-data">
      <div class="form-group">
        <label>email</label>
        <input type="email" class="form-control" placeholder="Masukkan email" name="email" required="required">
      </div>
      <input type="submit" name="delete" value="delete" class="btn btn-secondary">
    </form>

  </div>
<?php include 'config.php';
if (isset($_POST['delete'])) {
  $email = $_POST['email'];

  mysqli_query($connect, "DELETE FROM review WHERE email='$email'");
  header("location:index.php");
}
?>
</body>
</html>