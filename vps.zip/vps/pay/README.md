<div style="background: white;">
<div>
<h1 align="center">PAYMENT PAGES</h1>
</div>
<div align="center">
<img src="http://www.sanzstore.org/gambar/1.jpeg" height="700" width="400"><br>
<img src="http://www.sanzstore.org/gambar/2.jpeg" height="700" width="400"><br>
<img src="http://www.sanzstore.org/gambar/3.jpeg" height="700" width="400"><br>
<img src="http://www.sanzstore.org/gambar/4.jpeg" height="700" width="400"><br>
<img src="http://www.sanzstore.org/gambar/5.jpeg" height="700" width="400"><br>
</div>
<div align="center">
<h1 align="center">Follow me : </h1><br>
  <h4>https://github.com/sanzking</h4>
</div>
