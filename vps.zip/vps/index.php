<?php include "config.php"; ?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
<title>Hello, world!</title>
</head>
<style>
.menu {
  width: 25%;
  float: left;
  padding: 15px;
}

.main {
  width: 75%;
  float: left;
  padding: 15px;
}
.full {
  width: 100%;
  float: left;
  padding: 15px;
}
</style>
<body>
<div class="bg-dark p-5" align="center">
	<img src="lwm.png" height="100" width="300">
</div>

<div class="ms-3 me-3 mt-3 mb-3">
  <div class="row">
    <div class="container-fluid">
    <div class="row flex-nowrap" align="center">
        <div class="col py-3">
          <div class="full bg-light text-start">
          	<h1>DIJUAL VPS 1GB RAM / 1CPU</h1>
          	<h5>Harga <span class="badge bg-danger"><strike>Rp. 30,000</strike></span> <span class="badge bg-success">Rp. 20,000</span></h5>
          	<?php
 			$sql_hitung = mysqli_query($connect, "SELECT * FROM tbl_visitor");
 
 			while($row = mysqli_fetch_array($sql_hitung)){
 				$jml_sekarang = $row['counts'];
				$jml_baru = $jml_sekarang + 1;
 				$update_counts = mysqli_query($connect, "UPDATE tbl_visitor SET counts='$jml_baru'");
 			}
 			?>
          	<h5>Dilihat <span class="badge bg-secondary"><?php echo $jml_baru;?></span></h5>
          </div>
          <div class="main bg-light shadow">
            <div align="center">
            	<img src="vps.png" height="400" width="500">
            </div>
            <div class="mt-5 text-start">
            	<h2><span class="badge bg-primary">RINCIAN PRODUK/LAYANAN</span></h2><br>
            	<span class="fs-6 mb-1 badge bg-danger">$100 CREDIT</span><br>
            	<span class="fs-6 mb-1 badge bg-danger">AKTIF 1 TAHUN</span><br>
            	<span class="fs-6 mb-1 badge bg-danger">LIMIT 3 DROPLET</span><br>
            	<span class="fs-6 mb-1 badge bg-danger">DROPLET MAX SPEC 4GB RAM</span>
            	<br><br>
            	<h2><span class="badge bg-primary">KEUNTUNGAN MEMBERLI DIKAMI?</span></h2><br>
            	<span class="fs-6 mb-1 badge bg-dark">PROSES KILAT</span><br>
            	<span class="fs-6 mb-1 badge bg-dark">BERGARANSI</span><br>
            	<span class="fs-6 mb-1 badge bg-dark">PELAYANAN PELANGGAN FAST RESPON</span><br><br>
            	<h2><span class="badge bg-primary">F.A.Q *****</span></h2><br>
            	<span class="fs-6 mb-1 badge bg-dark">APAKAH PRODUK TERSEDIA?</span><br>
            	<span class="fs-6 mb-1 badge bg-warning text-dark">SELAGI PRODUK MASIH SAYA POSTING, PRODUK MASIH TERSEDIA KAK.</span><br>
            	<span class="fs-6 mb-1 badge bg-dark">BERAPA LAMA PROSES PESANAN?</span><br>
            	<span class="fs-6 mb-1 badge bg-warning text-dark">JIKA ADMIN ONLINE, PESANAN AKAN LANGSUNG DIPROSES KAK.</span><br>
            	<span class="fs-6 mb-1 badge bg-dark">APAKAH ADA GARANSI?</span><br>
            	<span class="fs-6 mb-1 badge bg-warning text-dark">ADA, KETIKA PERTAMA LOGIN. KAMI PASTIKAN SUDAH BERHASIL LOGIN.</span><br>
            </div>
            <div class="table-bordered p-5">
            	<table class="table text-center">
            		<tr>
            			<th class="fw-bold bg-success text-light">REVIEW POSITIF</th>
            			<th class="fw-bold bg-danger text-light">REVIEW NEGATIF</th>
            		</tr>
            		<tr>
            		<?php
            		$positif = mysqli_query($connect,"select * from review WHERE nilai='puas'");
            		$negatif = mysqli_query($connect,"select * from review WHERE nilai='tidak puas'");
            		$jum_pos = mysqli_num_rows($positif);
            		$jum_neg = mysqli_num_rows($negatif);
            			?>
            			<td class="fw-bold bg-success text-light"><?php echo $jum_pos; ?></td>
            			<td class="fw-bold bg-danger text-light"><?php echo $jum_neg; ?></td>
            		</tr>
            	</table>
            	<div class="p-5" style="background: #dfdfdf;">
            	<div class="bg-light shadow rounded p-5 me-5 ms-5 text-dark">
            	<?php
            	
            	$data = mysqli_query($connect,"select * from review");
				while($d = mysqli_fetch_array($data)){
				?>
            		<span class="fs-5"><i class="bi bi-person-fill"></i> <?php echo $d['email']; ?></span><br>
            		<?php
            		if($d['nilai']=='puas'){
            			?>
            			<span class="mb-3 badge bg-success"><?php echo $d['nilai']; ?></span><br>
            			<?php
            		}
            		else{
            			?>
            			<span class="mb-3 badge bg-danger"><?php echo $d['nilai']; ?></span><br>
            			<?php
            		}
            		?>
            		<?php echo $d['pesan']; ?>
            		<?php
            	}
           		?>
            	</div>
            	</div>
            </div>
          </div>
          <div class="p-3 text-start menu bg-light text-light">
          	<div class="d-grid gap-2">
            	<a class="btn btn-success text-light fw-bold text-center" href="pay">BELI SEKARANG</a>
            </div>
            <?php
            	
            $data = mysqli_query($connect,"select * from sukses");
			while($d = mysqli_fetch_array($data)){
				?>
            <h5 class="m-3 text-center text-dark">TERJUAL: <?php echo $d['good']; ?></h5>
            <?php
            }
        	?>
            <h5 class="text-dark fw-bold fs-3 text-center"><i class="bi bi-clock"></i> <span>INSTANT PRODUK</span></h5>
          </div>
        </div>
    </div>       
  </div>
</div>
</div>
<div class="bg-secondary p-1">
</div>
<div class="bg-secondary p-2">
  <div class="row text-light text-center">
    <div class="col-4">
      <b><i class="bi bi-clock"></i> Jam Buka</b>
      <br>
      <div class="mt-4">
        <b>Setiap hari</b>
      </div>
      <div>
        <span>08:00 - 20:00 WIB</span>
      </div>
    </div>
    <div class="col-4">
      <b><i class="bi bi-house"></i> Alamat</b>
      <div>
        <span>Jl. Rancasari Dalam No.B33 Rancasari Pamanukan</span>
      </div>
    </div>
    <div class="col-4">
      <b><i class="bi bi-envelope"></i> Kontak</b>
      <div>
        <span><i class="bi bi-telephone-fill"></i> 085723540943 – sanzking</span><br>
        <span><i class="bi bi-envelope-fill"></i> kapofaqih730@gmail.com</span>
      </div>
    </div>
  </div>
</div>
<div class="bg-dark p-1 text-center text-light font-monospace">
  <small>2021 - LIFEWITH.ME STORE OFFICIAL</small>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
</body>
</html>