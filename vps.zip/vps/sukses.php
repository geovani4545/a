<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<title>form review buku</title>
</head>
<body class="bg-secondary">
<div class="m-3 p-5 bg-success shadow rounded" align="center">
<form action="" method="post" enctype="multipart/form-data">
  <div align="center">
    <img src="lwm.png" height="100" width="300">
  </div>
  <div class="ms-3 me-3 mt-3 mb-5 p-2 fs-4 text-light text-center fw-bold rounded">FORM REVIEW PEMBELIAN</div>
  <div class="mb-3">
    <label for="sukses" class="form-label text-light">sukses</label>
    <input type="number" class="form-control" id="sukses" name="sukses" value="">
  </div>
  <div class="mb-3 d-grid gap-2 d-md-block">
  <input type="submit" name="gas" value="SUBMIT REVIEW" class="fw-bold btn btn-primary">
  </div>
</form>
<?php include 'config.php';
if (isset($_POST['gas'])) {
  $sukses = $_POST['sukses'];
  $data = mysqli_query($connect,"select * from sukses");
  $hasil = mysqli_num_rows($data);
  $a = $hasil + $sukses;
  if ($hasil==0) {
    mysqli_query($connect, "INSERT INTO sukses VALUES('$sukses')");
    header("location:index.php");
  }
  else{
      mysqli_query($connect, "UPDATE sukses SET good='$a'");
      header("location:index.php");
  }
}
?>
<form action="index.php">
<div class="d-grid gap-2 d-md-block">
    <input type="submit" class="btn btn-danger" value="KEMBALI">
</div>
</form>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  </body>
</html>